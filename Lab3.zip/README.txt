﻿How to use Jacob’s Pay Roll Linked List Program:

To compile to the code please extract the zip file and locate the new folder that has been unzipped. Once located make your way to this file within the linux terminal. After changing directory to this folder you can use the following commands:

    • g++ -std=c++11 main.cpp payroll.cpp payroll_list.cpp
    • ./a.out

You will then be able to run the code!

1) Within the zipped file is a file called “db.txt” within this text file you can find the names, pay rates, and hours worked by each employee. Their data is held on the same line as their name. Feel free to alter any of the data within this text file

Data Format for Input File: 
name(space)payrate(space)hoursworked.

2) When running the program you will be instructed to either select 1 to run the program by utilizing the first insert function or you may press 2 to use the second insert function which calls the first insert function within it.

3) Once selecting your choice of insert, you will see on your terminal a linked list of employees sorted from lowest to highest based on their pay rate.


