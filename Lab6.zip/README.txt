(a) The best case for Bubble Sort is :
   Ω(n) when the array is already Sorted

   The worst case for Bubble Sort is :
   O(n^2) when the array is sorted in descending Order

   The best case for Selection Sort is :
   Ω(n^2)

   The worst case for Selection Sort is :
   O(n^2)

   The best case for Insertion Sort is :
   Ω(n)

   The worst case for Insertion Sort is :
   O(n^2)

(b) As the number of elements increases so does the absolute time
it takes to run the function. As the size of elements increases so
does the absolute time it takes to run the function. Yes, you can use
the data to rectify the theoretical time complexity.

(c) Attached print out

(d) Best case would be the lowest elements in each of the sorts
However, by far the worst case would be if you had 10,000 elements
in a insertion sort, followed up by insertion sort with 1,000 elements
