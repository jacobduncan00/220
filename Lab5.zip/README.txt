﻿How to use Jacob’s Pay Roll Linked List Program:

To compile to the code please extract the zip file and locate the new folder that has been unzipped. Once located make your way to this file within the linux terminal. After changing directory to this folder you can use the following commands:

    • first type "make" (no parentheses)
    • then type ./main

Your code is compiled and you are now able to run the code!

1) Within the zipped file is a file called “db.txt” within this text file you can find the names, pay rates, and hours worked by each employee. Their data is held on the same line as their name. Feel free to alter any of the data within this text file

Data Format for Input File:
name(space)payrate(space)hoursworked.

2) Enjoy Dr. Anderson :)
