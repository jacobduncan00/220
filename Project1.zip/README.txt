README:

This program should be able to handle most erronious tasks. The only "bug/glitch" that I have found is when adding a course to a student. If the student is not found in the list, you are still prompted to put in the course information and after, you are told that the student is not in the list. However, besides this, this program can handle any sort of input validation. 

***Please follow directions specifically as they are used to make optimal use of the program!!!

This program will 
1) Allow user to input students, as well as their courses into a linked list
2) Edit Student information within the list
3) Remove a Student Node, along with all its classes or just simply one class node at a time
4) Print the list of students in the list along with the classes they are taking

In order to make this program run simply type:

1) make
2) ./main

After typing the two above lines into the terminal, one at a time and pressing enter in between, you are able to run my Database Software, enjoy!
